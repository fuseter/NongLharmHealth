package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;

import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import android.util.Log;
import android.net.Uri;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;
import java.util.Set;

import javax.sql.StatementEvent;


public class SettingActivity extends AppCompatActivity {

    ImageView btnbacksetting,btnLogout;
    EditText editName,editHeight,editAge,editWeight,gender;
    Button btnagree;

    private static final String TAG = "SettingActivity";


    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        btnbacksetting = findViewById(R.id.btnbacksetting);
        btnLogout = findViewById(R.id.btnLogout);
        editName = findViewById(R.id.editName);
        editHeight = findViewById(R.id.editHeight);
        editWeight = findViewById(R.id.editWeight);
        editAge = findViewById(R.id.editAge);
        gender = findViewById(R.id.gender);
        btnagree = findViewById(R.id.btnagree);


        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        final String userID = user.getUid();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };

        // Read from the database
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
//                String value = dataSnapshot.getValue(String.class);
                Object value = dataSnapshot.getValue();
                Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });


        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map map1 = (Map) dataSnapshot.child("user").child(userID).getValue();
                String  age = String.valueOf(map1.get("age"));
                String  gen = String.valueOf(map1.get("gen"));
                String  height = String.valueOf(map1.get("height"));
                String  name = String.valueOf(map1.get("name"));
                String  weight = String.valueOf(map1.get("weight"));

                String ageupdate = age;
                String genupdate = gen;
                String heightupdate = height;
                String nameupdate = name;
                String weightupdate = weight;

                editName.setText(nameupdate);
                editHeight.setText(heightupdate);
                editWeight.setText(weightupdate);
                editAge.setText(ageupdate);
                gender.setText(genupdate);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        btnagree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString();
                String height = editHeight.getText().toString();
                String weight = editWeight.getText().toString();
                String age = editAge.getText().toString();
                String gen = gender.getText().toString();

                if (name.isEmpty()){
                    editName.setError("โปรดกรอกชื่อ");
                    editName.requestFocus();
                }
                if (height.isEmpty()){
                    editHeight.setError("โปรดกรอกความสูง");
                    editHeight.requestFocus();
                }
                if (weight.isEmpty()){
                    editWeight.setError("โปรดกรอกน้ำหนัก");
                    editWeight.requestFocus();
                }
                if (age.isEmpty()){
                    editAge.setError("โปรดกรอกอายุ");
                    editAge.requestFocus();
                }
                if (gen.isEmpty()){
                    gender.setError("โปรดกรอกเพศ");
                    gender.requestFocus();
                }
                if (!(gen.endsWith("ชาย")|| gen.endsWith("หญิง"))){
                    gender.setError("โปรดกรอก ชาย-หญิง");
                    gender.requestFocus();
                    return;
                }
                else  if (name.isEmpty() && height.isEmpty() && weight.isEmpty() && age.isEmpty() && gen.isEmpty()){
                    Toast.makeText(SettingActivity.this,"โปรดกรอกข้อมูล",Toast.LENGTH_LONG).show();
                }

                else if (!(name.isEmpty() && height.isEmpty() && weight.isEmpty() && age.isEmpty() && gen.isEmpty())){
                    FirebaseUser user = mAuth.getCurrentUser();
                    String userID = user.getUid();
                    DataSetting dataSetting = new DataSetting(name,height,weight,age,gen);
                    myRef.child("user").child(userID).setValue(dataSetting);
                    Toast.makeText(SettingActivity.this,"แก้ไขเรียบร้อย",Toast.LENGTH_LONG).show();
                }
            }
        });


        btnbacksetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingActivity.this,ProfileActivity.class);
                startActivity(intent);
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(SettingActivity.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}

package com.example.nonglharmhealthy;

public class DataSetting {
    String name;
    String height;
    String weight;
    String age;
    String gen;

    public DataSetting(){

    }
    public DataSetting(String name, String height, String weight, String age, String gen) {
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.age = age;
        this.gen = gen;
    }

    public String getName() {
        return name;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getAge() {
        return age;
    }

    public String getGen() {
        return gen;
    }
}

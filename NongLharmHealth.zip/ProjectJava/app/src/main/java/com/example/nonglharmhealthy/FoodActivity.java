package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class FoodActivity extends AppCompatActivity {


    ImageView btnbackMHR,btnsaveMHR;
    EditText MHRweight;
    Button btnCalMHR;
    TextView showMHR;

    private static final String TAG = "SettingActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food);

        btnbackMHR = findViewById(R.id.btnbackMHR);
        btnsaveMHR = findViewById(R.id.btnsaveMHR);
        MHRweight = findViewById(R.id.MHRweight);
        btnCalMHR = findViewById(R.id.btnCalMHR);
        showMHR = findViewById(R.id.showMHR);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };

        btnbackMHR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FoodActivity.this,homeActivity.class);
                startActivity(intent);
            }
        });

        btnCalMHR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mhr();
            }
        });

    }

    protected void mhr(){
        String mhr = MHRweight.getText().toString();

        if (mhr.isEmpty()){
            MHRweight.setError("โปรดกรอกน้ำหนัก");
            MHRweight.requestFocus();
        }
        else{
            double mhrvalue = Double.parseDouble(mhr);
            double resultMHR = (206.9 - (0.67*mhrvalue));

            final String result = String.format("%.0f",resultMHR);
            showMHR.setText(result+" จังหวะ/นาที");


            btnsaveMHR.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String mhr = result;

                    if(mhr == null){
                        MHRweight.setError("โปรดกรอกน้ำหนัก");
                        MHRweight.requestFocus();
                    }
                    else {
                        FirebaseUser user = mAuth.getCurrentUser();
                        String userID = user.getUid();
                        myRef.child("HealthUser").child(userID).child("MHR").setValue(mhr).addOnCompleteListener(FoodActivity.this, new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(FoodActivity.this,"บันทึกข้อมูลเรียบร้อย",Toast.LENGTH_LONG).show();
                                }
                                else {
                                    Toast.makeText(FoodActivity.this,"เกิดข้อผิดพลาด",Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                }
            });
        }
    }
    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}

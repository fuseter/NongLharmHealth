package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BmrwomenActivity extends AppCompatActivity {

    ImageView btnbackwomen,saveWomen;
    TextView showBMRwomen;
    EditText womenweight, womenheight, womenage;
    Button btncalBMRwo;

    private static final String TAG = "SettingActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmrwomen);

        btnbackwomen = findViewById(R.id.btnbackwomen);
        showBMRwomen = findViewById(R.id.showBMRwomen);
        womenweight = findViewById(R.id.womenweight);
        womenheight = findViewById(R.id.womenheight);
        womenage = findViewById(R.id.womenage);
        btncalBMRwo = findViewById(R.id.btncalBMRwo);
        saveWomen = findViewById(R.id.saveWomen);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };

        btnbackwomen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BmrwomenActivity.this, CalActivity.class);
                startActivity(intent);
            }
        });

        btncalBMRwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bmr();
            }
        });
    }

    protected void bmr() {
        String weight = womenweight.getText().toString();
        String height = womenheight.getText().toString();
        String age = womenage.getText().toString();

        if (weight.isEmpty()) {
            womenweight.setError("โปรดกรอกน้ำหนัก");
            womenweight.requestFocus();
        }
        if (height.isEmpty()) {
            womenheight.setError("โปรดกรอกส่วนสูง");
            womenheight.requestFocus();
        }
        if (age.isEmpty()) {
            womenage.setError("โปรดกรอกอายุ");
            womenage.requestFocus();
        } else if (weight.isEmpty() && height.isEmpty() && age.isEmpty()) {
            Toast.makeText(BmrwomenActivity.this, "โปรดกรอกข้อมูล", Toast.LENGTH_LONG).show();
        }
        if (weight != null && !"".equals(weight) && height != null && !"".equals(height) && age != null && !"".equals(age)) {

            double weightValue = Double.parseDouble(weight);
            double heightValue = Double.parseDouble(height);
            double ageValue = Double.parseDouble(age);

            double resultBMR = 665 + (9.6*weightValue) + (1.8*heightValue) - (4.7*ageValue);

            final String result = String.format("%.0f", resultBMR);
            showBMRwomen.setText(result + " กิโลแคลอรี");


            saveWomen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String BMRwomen = result;
                    if (BMRwomen == null){
                        womenheight.setError("โปรดกรอกส่วนสูง");
                        womenweight.setError("โปรดกรอกน้ำหนัก");
                        womenage.setError("โปรดกรอกอายุ");
                        womenage.requestFocus();
                        womenweight.requestFocus();
                        womenheight.requestFocus();
                    }
                    else {
                        FirebaseUser user = mAuth.getCurrentUser();
                        String userID = user.getUid();
                        myRef.child("HealthUser").child(userID).child("BMR").setValue(BMRwomen).addOnCompleteListener(BmrwomenActivity.this, new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(BmrwomenActivity.this,"บันทึกข้อมูลเรียบร้อย",Toast.LENGTH_LONG).show();
                                }
                                else {
                                    Toast.makeText(BmrwomenActivity.this,"เกิดข้อผิดพลาด",Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                }
            });
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}


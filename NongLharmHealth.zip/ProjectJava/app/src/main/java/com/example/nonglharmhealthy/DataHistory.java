package com.example.nonglharmhealthy;

public class DataHistory {
    String name;
    String height;
    String age;
    String weight;
    String gen;

    public  DataHistory(){

    }

    public DataHistory(String name, String height, String age, String weight, String gen) {
        this.name = name;
        this.height = height;
        this.age = age;
        this.weight = weight;
        this.gen = gen;
    }


    public String getName() {
        return name;
    }

    public String getHeight() {
        return height;
    }

    public String getAge() {
        return age;
    }

    public String getWeight() {
        return weight;
    }

    public String getGen() {
        return gen;
    }
}

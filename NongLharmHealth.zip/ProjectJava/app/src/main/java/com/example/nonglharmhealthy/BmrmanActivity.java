package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BmrmanActivity extends AppCompatActivity {

    ImageView btnbackman,saveMan;
    EditText manweight,manheight,manage;
    Button btncalBMRma;
    TextView showBMRman;

    private static final String TAG = "SettingActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmrman);

        btnbackman = findViewById(R.id.btnbackman);
        manweight = findViewById(R.id.manweight);
        manheight = findViewById(R.id.manheight);
        manage = findViewById(R.id.manage);
        btncalBMRma = findViewById(R.id.btncalBMRma);
        showBMRman = findViewById(R.id.showBMRman);
        saveMan = findViewById(R.id.saveMan);



        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };

        btnbackman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BmrmanActivity.this,CalActivity.class);
                startActivity(intent);
            }
        });



        btncalBMRma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bmr();
            }
        });
    }

    protected void bmr(){

        String weight = manweight.getText().toString();
        String height = manheight.getText().toString();
        String age = manage.getText().toString();

        if (weight.isEmpty()){
            manweight.setError("โปรดกรอกน้ำหนัก");
            manweight.requestFocus();
        }
        if (height.isEmpty()){
            manheight.setError("โปรดกรอกส่วนสูง");
            manheight.requestFocus();
        }
        if (age.isEmpty()){
            manage.setError("โปรดกรอกอายุ");
            manage.requestFocus();
        }
        else if (weight.isEmpty() && height.isEmpty() && age.isEmpty()){
            Toast.makeText(BmrmanActivity.this,"โปรดกรอกข้อมูล",Toast.LENGTH_LONG).show();
        }

        if (weight != null && !"".equals(weight) && height != null && !"".equals(height) && age != null && !"".equals(age)){

            double weightValue = Double.parseDouble(weight);
            double heightValue = Double.parseDouble(height);
            double ageValue = Double.parseDouble(age);

            double resultBMR = 66 + (13.7*weightValue) + (5*heightValue) - (6.8*ageValue);

            final String result = String.format("%.0f", resultBMR);
            showBMRman.setText(result+" กิโลแคลอรี");

            saveMan.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String BMRman = result;
                    if (BMRman == null){
                        manheight.setError("โปรดกรอกส่วนสูง");
                        manweight.setError("โปรดกรอกน้ำหนัก");
                        manage.setError("โปรดกรอกอายุ");
                        manage.requestFocus();
                        manweight.requestFocus();
                        manheight.requestFocus();
                    }
                    else {
                        FirebaseUser user = mAuth.getCurrentUser();
                        String userID = user.getUid();
                        myRef.child("HealthUser").child(userID).child("BMR").setValue(BMRman).addOnCompleteListener(BmrmanActivity.this, new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(BmrmanActivity.this,"บันทึกข้อมูลเรียบร้อย",Toast.LENGTH_LONG).show();
                                }
                                else {
                                    Toast.makeText(BmrmanActivity.this,"เกิดข้อผิดพลาด",Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }

                }
            });


        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

}

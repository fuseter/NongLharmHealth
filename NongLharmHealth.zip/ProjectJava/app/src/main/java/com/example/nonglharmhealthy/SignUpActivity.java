package com.example.nonglharmhealthy;

import android.content.Intent;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.common.internal.Objects;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.lang.reflect.Array;

public class SignUpActivity extends AppCompatActivity {
    EditText emailsignup, passwordsignup;
    Button btnsignup;
    ImageView btnback;

    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        emailsignup = findViewById(R.id.emailsignup);
        passwordsignup = findViewById(R.id.passwordsignup);
        btnsignup = findViewById(R.id.btnsignup);
        btnback = findViewById(R.id.btnback);

        mAuth = FirebaseAuth.getInstance();

        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailsignup.getText().toString();
                String password = passwordsignup.getText().toString();



                if (!(email.endsWith("@hotmail.com") || email.endsWith("@gmail.com") || email.endsWith("@hotmail.co.th")
                        || email.endsWith("@outlook.com") || email.endsWith("outlook.co.th") || email.endsWith("yahoo.com"))){
                    emailsignup.setError("อีเมลไม่ถูกต้อง!!");
                    emailsignup.requestFocus();
                    return;
                }
                if (password.isEmpty()){
                    passwordsignup.setError("โปรดกรอกรหัสผ่าน");
                    passwordsignup.requestFocus();
                }
                if (password.length() < 6){
                    passwordsignup.setError("โปรดกรอกรหัสผ่านอย่างน้อย 6 ตัว!!");
                    passwordsignup.requestFocus();
                }
                else if (email.isEmpty() && password.isEmpty()){
                    Toast.makeText(SignUpActivity.this,"โปรดกรอกข้อมูล!!",Toast.LENGTH_LONG).show();
                }
                else if (!( email.isEmpty() && password.isEmpty() )){
                    mAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>(){
                                @Override
                                public void onComplete(Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Intent intent = new Intent(SignUpActivity.this,HistorySignupActivity.class);
                                        startActivity(intent);
                                    }
                                }
                            });
                }
                else {
                    Toast.makeText(SignUpActivity.this,"เกิดข้อผิดพลาด",Toast.LENGTH_LONG);
                }


            }
        });


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUpActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        
    }
}

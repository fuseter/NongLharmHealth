package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MindActivity extends AppCompatActivity {

    ImageView btnbackfeedback,btnsendfeedback;
    EditText inputFeedback;

    private static final String TAG = "SettingActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mind);

        btnbackfeedback = findViewById(R.id.btnbackfeedback);
        btnsendfeedback = findViewById(R.id.btnsendfeedback);
        inputFeedback = findViewById(R.id.inputFeedback);

        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };

        btnsendfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String feedback = inputFeedback.getText().toString();

                if (feedback.isEmpty()){
                    inputFeedback.setError("โปรดกรอกข้อมูล");
                    inputFeedback.requestFocus();
                }
                else {
                    FirebaseUser user = mAuth.getCurrentUser();
                    String userID = user.getUid();
                    myRef.child("Feedback").child(userID).child("comment").setValue(feedback).addOnCompleteListener(MindActivity.this, new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(MindActivity.this,"ส่ง Feedback เรียบร้อย",Toast.LENGTH_LONG).show();
                            }
                            else {
                                Toast.makeText(MindActivity.this,"เกิดข้อผิดพลาด",Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }


            }
        });












        btnbackfeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MindActivity.this,homeActivity.class);
                startActivity(intent);
            }
        });



    }
    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}

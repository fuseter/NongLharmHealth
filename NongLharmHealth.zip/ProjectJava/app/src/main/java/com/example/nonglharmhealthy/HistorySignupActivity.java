package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class

HistorySignupActivity extends AppCompatActivity {


    EditText namehis,heighthis,agehis,weighthis,gender;
    Button agreehistory;


    private static final String TAG = "SettingActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_signup);



        namehis = findViewById(R.id.namehis);
        heighthis = findViewById(R.id.heighthis);
        agehis = findViewById(R.id.agehis);
        weighthis = findViewById(R.id.weighthis);
        agreehistory = findViewById(R.id.agreehistory);
        gender = findViewById(R.id.gender);


        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };


        agreehistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = namehis.getText().toString();
                String height = heighthis.getText().toString();
                String age = agehis.getText().toString();
                String weight = weighthis.getText().toString();
                String gen = gender.getText().toString();

                if (name.isEmpty()){
                    namehis.setError("โปรดกรอกชื่อ-นามสกุล");
                    namehis.requestFocus();
                }
                if (height.isEmpty()){
                    heighthis.setError("โปรดกรอกส่วนสูง");
                    heighthis.requestFocus();
                }
                if (age.isEmpty()){
                    agehis.setError("โปรดกรอกอายุ");
                    agehis.requestFocus();
                }
                if (weight.isEmpty()){
                    weighthis.setError("โปรดกรอกน้ำหนัก");
                    weighthis.requestFocus();
                }
                if (gen.isEmpty()){
                    gender.setError("โปรดกรอกเพศ");
                    gender.requestFocus();
                }

                if (!(gen.endsWith("ชาย")|| gen.endsWith("หญิง"))){
                    gender.setError("โปรดกรอก ชาย-หญิง");
                    gender.requestFocus();
                    return;
                }
                else if (name.isEmpty() && height.isEmpty() && age.isEmpty() && weight.isEmpty() && gen.isEmpty()){
                    Toast.makeText(HistorySignupActivity.this,"โปรดกรอกข้อมูล",Toast.LENGTH_LONG).show();
                }
                else if (!(name.isEmpty() && height.isEmpty() && age.isEmpty() && weight.isEmpty() && gen.isEmpty())){
                    FirebaseUser user = mAuth.getCurrentUser();
                    String userID = user.getUid();
                    DataHistory dataHistory = new DataHistory(name,height,age,weight,gen);
                    myRef.child("user").child(userID).setValue(dataHistory).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {


                            if (task.isSuccessful()){
                                Toast.makeText(HistorySignupActivity.this,"ลงทะเบียนสำเร็จ!! โปรดเข้าสู่ระบบ",Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(HistorySignupActivity.this,MainActivity.class);
                                startActivity(intent);
                            }
                        }
                    });
                }

                else{
                    Toast.makeText(HistorySignupActivity.this,"เกิดข้อผิดพลาด!!",Toast.LENGTH_LONG).show();
                }


            }
        });




    }


    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }
}

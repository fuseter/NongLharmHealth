package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class KnowActivity extends AppCompatActivity {
    private ViewPager slideView;
    private SlideAdapter slideAdapter;

    private  ImageView btnbackknow;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_know);

        slideView = findViewById(R.id.slideView);
        btnbackknow = findViewById(R.id.btnbackknow);

        btnbackknow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(KnowActivity.this,homeActivity.class);
                startActivity(intent);
            }
        });

        slideAdapter = new SlideAdapter(this);

        slideView.setAdapter(slideAdapter);


    }


}

package com.example.nonglharmhealthy;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    TextView showBMR,showMHR,showBMI,nameUser,heightUser,weightUser,ageUser,genderUser,shownameuser;
    ImageView btnbackpro,btnsetting;

    private  static final String TAG = "ProfileActivity";

    private FirebaseDatabase mFirebaseDatabase;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private DatabaseReference myRef;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        btnbackpro = findViewById(R.id.btnbackpro);
        showBMI = findViewById(R.id.showBMI);

        nameUser = findViewById(R.id.nameUser);
        heightUser = findViewById(R.id.heightUser);
        weightUser = findViewById(R.id.weightUser);
        ageUser = findViewById(R.id.ageUser);
        genderUser = findViewById(R.id.genderUser);
        btnsetting = findViewById(R.id.btnsetting);
        shownameuser = findViewById(R.id.shownameuser);
        showMHR = findViewById(R.id.showMHR);
        showBMR = findViewById(R.id.showBMR);


        mAuth = FirebaseAuth.getInstance();
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        myRef = mFirebaseDatabase.getReference();
        FirebaseUser user = mAuth.getCurrentUser();
        final String userID = user.getUid();

        shownameuser.setText(user.getEmail());

        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    //user signed in
                    Log.d(TAG,"onAuthStateChanged : signed in : " + user.getUid());
                }
                else{
                    //user signed out
                    Log.d(TAG,"onAuthStateChanged : signed out : ");
                }
            }
        };


        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Map map1 = (Map) dataSnapshot.child("user").child(userID).getValue();
                Map map2 = (Map) dataSnapshot.child("HealthUser").child(userID).getValue();

                String  age = String.valueOf(map1.get("age"));
                String  gen = String.valueOf(map1.get("gen"));
                String  height = String.valueOf(map1.get("height"));
                String  name = String.valueOf(map1.get("name"));
                String  weight = String.valueOf(map1.get("weight"));

                if (dataSnapshot.child("HealthUser").child(userID).getValue() == null){
                    showBMI.setText("--");
                    showBMR.setText("--");
                    showMHR.setText("--");
                }
                if(dataSnapshot.child("HealthUser").child(userID).child("BMI").getValue() == null){
                    showBMI.setText("--");
                }
                if(dataSnapshot.child("HealthUser").child(userID).child("BMR").getValue() == null){
                    showBMR.setText("--");
                }
                if(dataSnapshot.child("HealthUser").child(userID).child("MHR").getValue() == null){
                    showMHR.setText("--");
                }
                if(dataSnapshot.child("HealthUser").child(userID).child("MHR").getValue() != null){
                    String mhr = String.valueOf(map2.get("MHR"));
                    showMHR.setText(mhr);
                }
                if(dataSnapshot.child("HealthUser").child(userID).child("BMI").getValue() != null){
                    String bmi = String.valueOf(map2.get("BMI"));
                    showBMI.setText(bmi);
                }
                if (dataSnapshot.child("HealthUser").child(userID).child("BMR").getValue() != null){
                    String bmr = String.valueOf(map2.get("BMR"));
                    showBMR.setText(bmr);
                }

                nameUser.setText(name);
                heightUser.setText(height);
                weightUser.setText(weight);
                ageUser.setText(age);
                genderUser.setText(gen);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });







        btnbackpro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,homeActivity.class);
                startActivity(intent);
            }
        });

        btnsetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this,SettingActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

}

package com.example.nonglharmhealthy;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;

public class ActActivity extends AppCompatActivity {

    ImageView btnstop,btnstart,circle;
    Chronometer time;
    Animation rotate;
    long pause;
    boolean running;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act);
        btnstart = findViewById(R.id.btnstart);
        btnstop = findViewById(R.id.btnstop);
        time = findViewById(R.id.time);
        circle = findViewById(R.id.circle);

        rotate = AnimationUtils.loadAnimation(ActActivity.this,R.anim.rotation);

        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                circle.startAnimation(rotate);
                time.setFormat("%s");
                time.setBase(SystemClock.elapsedRealtime()-pause);
                time.start();
                btnstop.setVisibility(View.INVISIBLE);
                btnstop.setVisibility(View.VISIBLE);
            }
        });

        btnstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time.stop();
                running = true;
                time.setBase(SystemClock.elapsedRealtime());
                pause = 0;
                rotate.cancel();
                circle.setAnimation(rotate);
                btnstart.setVisibility(View.VISIBLE);
                btnstop.setVisibility(View.INVISIBLE);

            }
        });

    }
}
